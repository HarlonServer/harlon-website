Text for Line Numbers:
Arial
25px
Antialiasing disabled